package com.example.stickytodo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.stickytodo.data.TaskRepository
import com.example.stickytodo.ui.theme.InkDark
import com.example.stickytodo.ui.theme.NoteYellowMid
import com.example.stickytodo.ui.theme.StickyTodoTheme
import kotlinx.coroutines.launch

/**
 * Glance widgets can't show a real dropdown popup, so tapping the note name on the
 * home-screen widget opens this small picker instead — pick a note and you're dropped
 * straight back to your home screen with the widget showing that note.
 */
class SwitchNoteActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = TaskRepository(applicationContext)

        setContent {
            StickyTodoTheme {
                val notes by repository.notesFlow.collectAsState(initial = emptyList())
                val activeNote by repository.activeNoteFlow.collectAsState(initial = null)
                val scope = rememberCoroutineScope()

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier
                            .padding(horizontal = 32.dp)
                            .widthIn(max = 280.dp)
                            .background(NoteYellowMid, RoundedCornerShape(12.dp))
                            .padding(20.dp)
                    ) {
                        Text("Switch note", color = InkDark, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(12.dp))

                        notes.forEach { note ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        scope.launch {
                                            repository.setActiveNote(note.id)
                                            finish()
                                        }
                                    }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (note.id == activeNote?.id) {
                                    Icon(Icons.Filled.Check, contentDescription = null, tint = InkDark)
                                } else {
                                    Spacer(Modifier.size(24.dp))
                                }
                                Spacer(Modifier.width(8.dp))
                                Text(note.title, color = InkDark)
                            }
                        }

                        Spacer(Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { finish() }) { Text("Close") }
                        }
                    }
                }
            }
        }
    }
}
