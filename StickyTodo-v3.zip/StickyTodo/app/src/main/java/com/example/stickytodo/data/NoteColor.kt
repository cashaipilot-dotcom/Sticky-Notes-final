package com.example.stickytodo.data

/** The sticky note's paper color, chosen by the user and remembered across app + widget. */
enum class NoteColor {
    YELLOW, GREEN, BLUE
}
