package com.example.stickytodo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.stickytodo.data.TaskRepository
import com.example.stickytodo.ui.theme.InkDark
import com.example.stickytodo.ui.theme.NoteYellowMid
import com.example.stickytodo.ui.theme.StickyTodoTheme
import kotlinx.coroutines.launch

/**
 * Widgets can't host a real keyboard/text field, so tapping "+ Add task" on the home-screen
 * widget opens this tiny popup instead. Type a task, tap Save, and you're dropped straight
 * back to your home screen.
 */
class QuickAddTaskActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = TaskRepository(applicationContext)

        setContent {
            StickyTodoTheme {
                var text by remember { mutableStateOf("") }
                val scope = rememberCoroutineScope()

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier
                            .padding(horizontal = 32.dp)
                            .background(NoteYellowMid, RoundedCornerShape(12.dp))
                            .padding(20.dp)
                    ) {
                        Text(
                            "Add a task",
                            color = InkDark,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = text,
                            onValueChange = { text = it },
                            placeholder = { Text("What do you need to do?") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { finish() }) { Text("Cancel") }
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = {
                                val toSave = text.trim()
                                if (toSave.isNotEmpty()) {
                                    scope.launch {
                                        repository.addTask(toSave)
                                        finish()
                                    }
                                } else {
                                    finish()
                                }
                            }) { Text("Save") }
                        }
                    }
                }
            }
        }
    }
}
