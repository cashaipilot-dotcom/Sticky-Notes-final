package com.example.stickytodo.data

import kotlinx.serialization.Serializable

@Serializable
data class Task(
    val id: Long,
    val text: String,
    val done: Boolean = false,
    val starred: Boolean = false
)
