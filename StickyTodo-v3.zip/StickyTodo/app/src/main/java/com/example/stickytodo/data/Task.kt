package com.example.stickytodo.data

import kotlinx.serialization.Serializable

@Serializable
data class Task(
    val id: Long,
    val text: String,
    val done: Boolean = false,
    val starred: Boolean = false,
    /** Epoch millis when this task was last marked done; null while incomplete. Used to
     *  automatically clear it out 24 hours after completion. */
    val completedAt: Long? = null
)
