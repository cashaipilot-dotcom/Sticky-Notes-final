package com.example.stickytodo.data

import kotlinx.serialization.Serializable

/** One sticky note — e.g. "Personal" or "Work" — with its own color and task list. */
@Serializable
data class StickyNoteData(
    val id: Long,
    val title: String,
    val color: NoteColor = NoteColor.YELLOW,
    val tasks: List<Task> = emptyList()
)
