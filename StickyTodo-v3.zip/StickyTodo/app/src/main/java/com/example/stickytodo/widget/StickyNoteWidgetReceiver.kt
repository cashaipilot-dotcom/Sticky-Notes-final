package com.example.stickytodo.widget

import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver

/** Entry point Android uses to bind the Glance widget to a home-screen widget instance. */
class StickyNoteWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = StickyNoteWidget()
}
