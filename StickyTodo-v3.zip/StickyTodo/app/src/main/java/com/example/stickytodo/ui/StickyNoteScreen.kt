package com.example.stickytodo.ui

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.stickytodo.data.NoteColor
import com.example.stickytodo.data.Task
import com.example.stickytodo.ui.theme.*
import com.example.stickytodo.viewmodel.TaskViewModel
import com.example.stickytodo.widget.StickyNoteWidgetReceiver
import kotlinx.coroutines.delay
import java.util.Locale

private fun gradientFor(color: NoteColor): List<Color> = when (color) {
    NoteColor.YELLOW -> listOf(NoteYellowLight, NoteYellowMid, NoteYellowDark)
    NoteColor.GREEN -> listOf(NoteGreenLight, NoteGreenMid, NoteGreenDark)
    NoteColor.BLUE -> listOf(NoteBlueLight, NoteBlueMid, NoteBlueDark)
}

private fun swatchColorFor(color: NoteColor): Color = when (color) {
    NoteColor.YELLOW -> NoteYellowDark
    NoteColor.GREEN -> NoteGreenDark
    NoteColor.BLUE -> NoteBlueDark
}

/** A simple jagged bottom edge, mimicking a hand-torn strip of paper. */
private class TornBottomEdge(
    private val toothWidthDp: androidx.compose.ui.unit.Dp = 16.dp,
    private val toothHeightDp: androidx.compose.ui.unit.Dp = 6.dp
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val toothW = with(density) { toothWidthDp.toPx() }
        val toothH = with(density) { toothHeightDp.toPx() }
        val path = Path().apply {
            moveTo(0f, 0f)
            lineTo(size.width, 0f)
            lineTo(size.width, size.height - toothH)
            var x = size.width
            var pointUp = false
            while (x > 0.5f) {
                val nextX = (x - toothW).coerceAtLeast(0f)
                val y = if (pointUp) size.height - toothH else size.height
                lineTo(nextX, y)
                pointUp = !pointUp
                x = nextX
            }
            lineTo(0f, size.height - toothH)
            close()
        }
        return Outline.Generic(path)
    }
}

@Composable
fun StickyNoteScreen(viewModel: TaskViewModel) {
    val tasks by viewModel.tasks.collectAsState()
    val noteColor by viewModel.noteColor.collectAsState()
    val completedCount by viewModel.completedCount.collectAsState()
    var input by remember { mutableStateOf("") }
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CorkBrown)
    ) {
        CorkTexture(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            StickyNoteCard(
                tasks = tasks,
                noteColor = noteColor,
                onColorChange = viewModel::setNoteColor,
                completedCount = completedCount,
                input = input,
                onInputChange = { input = it },
                onAdd = {
                    viewModel.addTask(input)
                    input = ""
                },
                onToggle = viewModel::toggleTask,
                onToggleStar = viewModel::toggleStar,
                onDelete = viewModel::deleteTask
            )

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedButton(
                onClick = {
                    val appWidgetManager = AppWidgetManager.getInstance(context)
                    val provider = ComponentName(context, StickyNoteWidgetReceiver::class.java)
                    if (appWidgetManager.isRequestPinAppWidgetSupported) {
                        appWidgetManager.requestPinAppWidget(provider, null, null)
                    } else {
                        Toast.makeText(
                            context,
                            "Your launcher doesn't support this shortcut. Long-press your home screen → Widgets → Sticky To-Do instead.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = InkDark)
            ) {
                Icon(Icons.Filled.PushPin, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add widget to Home Screen")
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "If nothing happens above, long-press your home screen → Widgets → Sticky To-Do.",
                color = InkMuted,
                fontSize = 12.sp,
                modifier = Modifier.widthIn(max = 300.dp)
            )
        }
    }
}

@Composable
private fun StickyNoteCard(
    tasks: List<Task>,
    noteColor: NoteColor,
    onColorChange: (NoteColor) -> Unit,
    completedCount: Int,
    input: String,
    onInputChange: (String) -> Unit,
    onAdd: () -> Unit,
    onToggle: (Long) -> Unit,
    onToggleStar: (Long) -> Unit,
    onDelete: (Long) -> Unit
) {
    val doneCount = tasks.count { it.done }
    val gradient = gradientFor(noteColor)
    val cardShape = remember { TornBottomEdge() }

    var showCelebration by remember { mutableStateOf(false) }
    var wasAllDone by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current

    LaunchedEffect(doneCount, tasks.size) {
        val allDoneNow = tasks.isNotEmpty() && doneCount == tasks.size
        if (allDoneNow && !wasAllDone) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            showCelebration = true
            delay(1600)
            showCelebration = false
        }
        wasAllDone = allDoneNow
    }

    Box(
        modifier = Modifier
            .widthIn(max = 360.dp)
            .graphicsLayer { rotationZ = -1.5f }
    ) {
        Column(
            modifier = Modifier
                .shadow(elevation = 14.dp, shape = cardShape, clip = false)
                .clip(cardShape)
                .background(Brush.linearGradient(gradient))
                .padding(start = 22.dp, end = 22.dp, top = 34.dp, bottom = 22.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "To-Do List",
                    style = MaterialTheme.typography.titleLarge,
                    color = InkDark
                )
                ColorSwatches(selected = noteColor, onSelect = onColorChange)
            }

            Spacer(modifier = Modifier.height(14.dp))

            AddTaskRow(input = input, onInputChange = onInputChange, onAdd = onAdd)

            Spacer(modifier = Modifier.height(10.dp))

            if (tasks.isEmpty()) {
                Text(
                    text = "Nothing here yet — add something above!",
                    style = MaterialTheme.typography.bodyLarge,
                    color = InkMuted
                )
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 320.dp)
                ) {
                    items(tasks, key = { it.id }) { task ->
                        TaskRow(task = task, onToggle = onToggle, onToggleStar = onToggleStar, onDelete = onDelete)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            HorizontalDivider(color = InkMuted.copy(alpha = 0.25f))
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "$doneCount of ${tasks.size} done",
                style = MaterialTheme.typography.labelSmall,
                color = InkMuted
            )
            if (completedCount > 0) {
                Text(
                    text = "🏆 $completedCount tasks conquered",
                    style = MaterialTheme.typography.labelSmall,
                    color = InkMuted
                )
            }
        }

        // Pushpin, overlapping the top edge of the note.
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-16).dp)
                .shadow(elevation = 6.dp, shape = CircleShape)
                .size(32.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(PinRedHighlight, PinRed))),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.PushPin,
                contentDescription = null,
                tint = Color(0xFFFECACA),
                modifier = Modifier.size(16.dp).graphicsLayer { rotationZ = 45f }
            )
        }

        // Washi-tape accent, top-left, layered under the pin for a scrapbook feel.
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .offset(x = 14.dp, y = (-9).dp)
                .size(width = 54.dp, height = 22.dp)
                .graphicsLayer { rotationZ = -9f }
                .background(gradient.last().copy(alpha = 0.65f), RoundedCornerShape(2.dp))
        )

        // Small sprig accent, bottom-right, echoing a dried-flower scrapbook touch.
        FlowerSprig(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .offset(x = (-14).dp, y = (-18).dp),
            color = gradient.last()
        )

        // Celebration burst, shown briefly when every task gets checked off.
        AnimatedVisibility(
            visible = showCelebration,
            modifier = Modifier.align(Alignment.Center),
            enter = fadeIn(tween(200)) + scaleIn(tween(250), initialScale = 0.6f),
            exit = fadeOut(tween(300)) + scaleOut(tween(300), targetScale = 0.8f)
        ) {
            Box(
                modifier = Modifier
                    .shadow(elevation = 10.dp, shape = RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .background(InkDark)
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "🎉 All done!",
                    color = NoteYellowLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
private fun FlowerSprig(modifier: Modifier = Modifier, color: Color) {
    val stemColor = InkMuted.copy(alpha = 0.55f)
    val leafColor = color.copy(alpha = 0.9f)
    Canvas(modifier = modifier.size(width = 30.dp, height = 42.dp)) {
        drawLine(
            color = stemColor,
            start = Offset(size.width * 0.55f, size.height),
            end = Offset(size.width * 0.35f, size.height * 0.1f),
            strokeWidth = 2f
        )
        val leafSpots = listOf(0.25f, 0.45f, 0.65f, 0.85f)
        leafSpots.forEachIndexed { i, t ->
            val x = size.width * 0.35f + (size.width * 0.2f) * (1f - t)
            val y = size.height * (1f - t)
            rotate(degrees = if (i % 2 == 0) -35f else 35f, pivot = Offset(x, y)) {
                drawOval(
                    color = leafColor,
                    topLeft = Offset(x - 5f, y - 2.5f),
                    size = Size(10f, 5f)
                )
            }
        }
    }
}

@Composable
private fun ColorSwatches(selected: NoteColor, onSelect: (NoteColor) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        NoteColor.values().forEach { color ->
            val isSelected = color == selected
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(swatchColorFor(color))
                    .then(
                        if (isSelected) Modifier.border(2.dp, InkDark, CircleShape) else Modifier
                    )
                    .clickable { onSelect(color) }
            )
        }
    }
}

@Composable
private fun AddTaskRow(input: String, onInputChange: (String) -> Unit, onAdd: () -> Unit) {
    val context = LocalContext.current

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                onInputChange(spoken)
            }
        }
    }

    Row(verticalAlignment = Alignment.Bottom) {
        TextField(
            value = input,
            onValueChange = onInputChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Add a task...", color = InkMuted.copy(alpha = 0.7f)) },
            textStyle = MaterialTheme.typography.bodyLarge.copy(color = InkDark),
            singleLine = true,
            colors = TextFieldDefaults.colors(
                unfocusedContainerColor = Color.Transparent,
                focusedContainerColor = Color.Transparent,
                unfocusedIndicatorColor = InkMuted.copy(alpha = 0.4f),
                focusedIndicatorColor = InkDark,
                cursorColor = InkDark
            )
        )
        IconButton(
            onClick = {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your task")
                }
                if (intent.resolveActivity(context.packageManager) != null) {
                    speechLauncher.launch(intent)
                } else {
                    Toast.makeText(context, "Voice input isn't available on this device.", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.size(40.dp)
        ) {
            Icon(Icons.Filled.Mic, contentDescription = "Add task by voice", tint = InkDark)
        }
        Spacer(modifier = Modifier.width(4.dp))
        Button(
            onClick = {
                if (input.isNotBlank()) onAdd()
            },
            colors = ButtonDefaults.buttonColors(containerColor = InkDark, contentColor = NoteYellowLight),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Add", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun TaskRow(task: Task, onToggle: (Long) -> Unit, onToggleStar: (Long) -> Unit, onDelete: (Long) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle(task.id) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CheckSquare(done = task.done)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "• ${task.text}",
            style = MaterialTheme.typography.bodyLarge,
            color = if (task.done) InkMuted else InkDark,
            textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = { onToggleStar(task.id) }, modifier = Modifier.size(28.dp)) {
            Icon(
                imageVector = if (task.starred) Icons.Filled.Star else Icons.Filled.StarBorder,
                contentDescription = if (task.starred) "Unpin task" else "Pin task to top",
                tint = if (task.starred) Color(0xFFCA8A04) else InkMuted,
                modifier = Modifier.size(18.dp)
            )
        }
        IconButton(onClick = { onDelete(task.id) }, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Filled.Delete, contentDescription = "Delete task", tint = InkMuted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun CheckSquare(done: Boolean) {
    val shape = RoundedCornerShape(4.dp)
    Box(
        modifier = Modifier
            .size(20.dp)
            .clip(shape)
            .background(if (done) CheckGreen else Color.Transparent)
            .border(1.5.dp, if (done) CheckGreen else InkMuted.copy(alpha = 0.6f), shape),
        contentAlignment = Alignment.Center
    ) {
        if (done) {
            Icon(Icons.Filled.Check, contentDescription = null, tint = NoteYellowLight, modifier = Modifier.size(13.dp))
        }
    }
}

@Composable
private fun CorkTexture(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val step = 26f
        var y = 0f
        var row = 0
        while (y < size.height) {
            var x = if (row % 2 == 0) 0f else step / 2f
            while (x < size.width) {
                drawCircle(
                    color = Color.Black.copy(alpha = 0.06f),
                    radius = 1.6f,
                    center = Offset(x, y)
                )
                x += step
            }
            y += step
            row++
        }
    }
}
