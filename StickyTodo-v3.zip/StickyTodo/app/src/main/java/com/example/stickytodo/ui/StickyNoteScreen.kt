package com.example.stickytodo.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.stickytodo.data.NoteColor
import com.example.stickytodo.data.Task
import com.example.stickytodo.ui.theme.*
import com.example.stickytodo.viewmodel.TaskViewModel
import com.example.stickytodo.widget.StickyNoteWidgetReceiver

private fun gradientFor(color: NoteColor): List<Color> = when (color) {
    NoteColor.YELLOW -> listOf(NoteYellowLight, NoteYellowMid, NoteYellowDark)
    NoteColor.GREEN -> listOf(NoteGreenLight, NoteGreenMid, NoteGreenDark)
    NoteColor.BLUE -> listOf(NoteBlueLight, NoteBlueMid, NoteBlueDark)
}

private fun swatchColorFor(color: NoteColor): Color = when (color) {
    NoteColor.YELLOW -> NoteYellowDark
    NoteColor.GREEN -> NoteGreenDark
    NoteColor.BLUE -> NoteBlueDark
}

/** A simple jagged bottom edge, mimicking a hand-torn strip of paper. */
private class TornBottomEdge(
    private val toothWidthDp: androidx.compose.ui.unit.Dp = 16.dp,
    private val toothHeightDp: androidx.compose.ui.unit.Dp = 6.dp
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val toothW = with(density) { toothWidthDp.toPx() }
        val toothH = with(density) { toothHeightDp.toPx() }
        val path = Path().apply {
            moveTo(0f, 0f)
            lineTo(size.width, 0f)
            lineTo(size.width, size.height - toothH)
            var x = size.width
            var pointUp = false
            while (x > 0.5f) {
                val nextX = (x - toothW).coerceAtLeast(0f)
                val y = if (pointUp) size.height - toothH else size.height
                lineTo(nextX, y)
                pointUp = !pointUp
                x = nextX
            }
            lineTo(0f, size.height - toothH)
            close()
        }
        return Outline.Generic(path)
    }
}

@Composable
fun StickyNoteScreen(viewModel: TaskViewModel) {
    val tasks by viewModel.tasks.collectAsState()
    val noteColor by viewModel.noteColor.collectAsState()
    var input by remember { mutableStateOf("") }
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CorkBrown)
    ) {
        CorkTexture(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            StickyNoteCard(
                tasks = tasks,
                noteColor = noteColor,
                onColorChange = viewModel::setNoteColor,
                input = input,
                onInputChange = { input = it },
                onAdd = {
                    viewModel.addTask(input)
                    input = ""
                },
                onToggle = viewModel::toggleTask,
                onDelete = viewModel::deleteTask
            )

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedButton(
                onClick = {
                    val appWidgetManager = AppWidgetManager.getInstance(context)
                    val provider = ComponentName(context, StickyNoteWidgetReceiver::class.java)
                    if (appWidgetManager.isRequestPinAppWidgetSupported) {
                        appWidgetManager.requestPinAppWidget(provider, null, null)
                    } else {
                        Toast.makeText(
                            context,
                            "Your launcher doesn't support this shortcut. Long-press your home screen → Widgets → Sticky To-Do instead.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = InkDark)
            ) {
                Icon(Icons.Filled.PushPin, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add widget to Home Screen")
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "If nothing happens above, long-press your home screen → Widgets → Sticky To-Do.",
                color = InkMuted,
                fontSize = 12.sp,
                modifier = Modifier.widthIn(max = 300.dp)
            )
        }
    }
}

@Composable
private fun StickyNoteCard(
    tasks: List<Task>,
    noteColor: NoteColor,
    onColorChange: (NoteColor) -> Unit,
    input: String,
    onInputChange: (String) -> Unit,
    onAdd: () -> Unit,
    onToggle: (Long) -> Unit,
    onDelete: (Long) -> Unit
) {
    val doneCount = tasks.count { it.done }
    val gradient = gradientFor(noteColor)
    val cardShape = remember { TornBottomEdge() }

    Box(
        modifier = Modifier
            .widthIn(max = 360.dp)
            .graphicsLayer { rotationZ = -1.5f }
    ) {
        Column(
            modifier = Modifier
                .shadow(elevation = 14.dp, shape = cardShape, clip = false)
                .clip(cardShape)
                .background(Brush.linearGradient(gradient))
                .padding(start = 22.dp, end = 22.dp, top = 34.dp, bottom = 22.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "To-Do List",
                    style = MaterialTheme.typography.titleLarge,
                    color = InkDark
                )
                ColorSwatches(selected = noteColor, onSelect = onColorChange)
            }

            Spacer(modifier = Modifier.height(14.dp))

            AddTaskRow(input = input, onInputChange = onInputChange, onAdd = onAdd)

            Spacer(modifier = Modifier.height(10.dp))

            if (tasks.isEmpty()) {
                Text(
                    text = "Nothing here yet — add something above!",
                    style = MaterialTheme.typography.bodyLarge,
                    color = InkMuted
                )
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 320.dp)
                ) {
                    items(tasks, key = { it.id }) { task ->
                        TaskRow(task = task, onToggle = onToggle, onDelete = onDelete)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            HorizontalDivider(color = InkMuted.copy(alpha = 0.25f))
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "$doneCount of ${tasks.size} done",
                style = MaterialTheme.typography.labelSmall,
                color = InkMuted
            )
        }

        // Pushpin, overlapping the top edge of the note.
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-16).dp)
                .shadow(elevation = 6.dp, shape = CircleShape)
                .size(32.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(PinRedHighlight, PinRed))),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.PushPin,
                contentDescription = null,
                tint = Color(0xFFFECACA),
                modifier = Modifier.size(16.dp).graphicsLayer { rotationZ = 45f }
            )
        }

        // Washi-tape accent, top-left, layered under the pin for a scrapbook feel.
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .offset(x = 14.dp, y = (-9).dp)
                .size(width = 54.dp, height = 22.dp)
                .graphicsLayer { rotationZ = -9f }
                .background(gradient.last().copy(alpha = 0.65f), RoundedCornerShape(2.dp))
        )
    }
}

@Composable
private fun ColorSwatches(selected: NoteColor, onSelect: (NoteColor) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        NoteColor.values().forEach { color ->
            val isSelected = color == selected
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(swatchColorFor(color))
                    .then(
                        if (isSelected) Modifier.border(2.dp, InkDark, CircleShape) else Modifier
                    )
                    .clickable { onSelect(color) }
            )
        }
    }
}

@Composable
private fun AddTaskRow(input: String, onInputChange: (String) -> Unit, onAdd: () -> Unit) {
    Row(verticalAlignment = Alignment.Bottom) {
        TextField(
            value = input,
            onValueChange = onInputChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Add a task...", color = InkMuted.copy(alpha = 0.7f)) },
            textStyle = MaterialTheme.typography.bodyLarge.copy(color = InkDark),
            singleLine = true,
            colors = TextFieldDefaults.colors(
                unfocusedContainerColor = Color.Transparent,
                focusedContainerColor = Color.Transparent,
                unfocusedIndicatorColor = InkMuted.copy(alpha = 0.4f),
                focusedIndicatorColor = InkDark,
                cursorColor = InkDark
            )
        )
        Spacer(modifier = Modifier.width(8.dp))
        Button(
            onClick = {
                if (input.isNotBlank()) onAdd()
            },
            colors = ButtonDefaults.buttonColors(containerColor = InkDark, contentColor = NoteYellowLight),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Add", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun TaskRow(task: Task, onToggle: (Long) -> Unit, onDelete: (Long) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle(task.id) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CheckSquare(done = task.done)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "• ${task.text}",
            style = MaterialTheme.typography.bodyLarge,
            color = if (task.done) InkMuted else InkDark,
            textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = { onDelete(task.id) }, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Filled.Delete, contentDescription = "Delete task", tint = InkMuted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun CheckSquare(done: Boolean) {
    val shape = RoundedCornerShape(4.dp)
    Box(
        modifier = Modifier
            .size(20.dp)
            .clip(shape)
            .background(if (done) CheckGreen else Color.Transparent)
            .border(1.5.dp, if (done) CheckGreen else InkMuted.copy(alpha = 0.6f), shape),
        contentAlignment = Alignment.Center
    ) {
        if (done) {
            Icon(Icons.Filled.Check, contentDescription = null, tint = NoteYellowLight, modifier = Modifier.size(13.dp))
        }
    }
}

@Composable
private fun CorkTexture(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val step = 26f
        var y = 0f
        var row = 0
        while (y < size.height) {
            var x = if (row % 2 == 0) 0f else step / 2f
            while (x < size.width) {
                drawCircle(
                    color = Color.Black.copy(alpha = 0.06f),
                    radius = 1.6f,
                    center = Offset(x, y)
                )
                x += step
            }
            y += step
            row++
        }
    }
}
