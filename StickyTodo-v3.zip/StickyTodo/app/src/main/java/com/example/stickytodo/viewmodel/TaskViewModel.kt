package com.example.stickytodo.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.stickytodo.data.NoteColor
import com.example.stickytodo.data.StickyNoteData
import com.example.stickytodo.data.TaskRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private val PLACEHOLDER_NOTE = StickyNoteData(id = -1L, title = "Loading…")

class TaskViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TaskRepository(application)

    val notes: StateFlow<List<StickyNoteData>> = repository.notesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    val activeNote: StateFlow<StickyNoteData> = repository.activeNoteFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = PLACEHOLDER_NOTE
    )

    val completedCount: StateFlow<Int> = repository.completedCountFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = 0
    )

    fun addTask(text: String) {
        val noteId = activeNote.value.id
        if (text.isBlank() || noteId < 0) return
        viewModelScope.launch { repository.addTask(noteId, text) }
    }

    fun toggleTask(taskId: Long) {
        val noteId = activeNote.value.id
        if (noteId < 0) return
        viewModelScope.launch { repository.toggleTask(noteId, taskId) }
    }

    fun toggleStar(taskId: Long) {
        val noteId = activeNote.value.id
        if (noteId < 0) return
        viewModelScope.launch { repository.toggleStar(noteId, taskId) }
    }

    fun deleteTask(taskId: Long) {
        val noteId = activeNote.value.id
        if (noteId < 0) return
        viewModelScope.launch { repository.deleteTask(noteId, taskId) }
    }

    fun setNoteColor(color: NoteColor) {
        val noteId = activeNote.value.id
        if (noteId < 0) return
        viewModelScope.launch { repository.setNoteColor(noteId, color) }
    }

    fun renameActiveNote(newTitle: String) {
        val noteId = activeNote.value.id
        if (noteId < 0) return
        viewModelScope.launch { repository.renameNote(noteId, newTitle) }
    }

    fun addNote(title: String) {
        viewModelScope.launch { repository.addNote(title) }
    }

    fun selectNote(noteId: Long) {
        viewModelScope.launch { repository.setActiveNote(noteId) }
    }
}
