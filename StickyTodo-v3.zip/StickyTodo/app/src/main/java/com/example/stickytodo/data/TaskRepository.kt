package com.example.stickytodo.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.glance.appwidget.updateAll
import com.example.stickytodo.widget.StickyNoteWidget
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sticky_todo_prefs")

/**
 * Single source of truth for tasks and note color. Both MainActivity (via TaskViewModel) and
 * the Glance app widget read from / write to this repository, so the two stay in sync.
 */
class TaskRepository(private val context: Context) {

    private val tasksKey = stringPreferencesKey("tasks_json")
    private val noteColorKey = stringPreferencesKey("note_color")
    private val completedCountKey = intPreferencesKey("completed_count")
    private val json = Json { ignoreUnknownKeys = true }

    val tasksFlow: Flow<List<Task>> = context.dataStore.data.map { prefs ->
        decodeTasks(prefs[tasksKey]).sortedWith(
            compareBy<Task> { it.done }.thenByDescending { it.starred }
        )
    }

    val noteColorFlow: Flow<NoteColor> = context.dataStore.data.map { prefs ->
        decodeColor(prefs[noteColorKey])
    }

    /** Lifetime count of tasks ever completed — an achievement counter that never decreases. */
    val completedCountFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[completedCountKey] ?: 0
    }

    suspend fun addTask(text: String) = mutateTasks { tasks ->
        tasks + Task(id = System.currentTimeMillis(), text = text, done = false)
    }

    suspend fun toggleTask(id: Long) {
        context.dataStore.edit { prefs ->
            val current = decodeTasks(prefs[tasksKey])
            var justCompleted = false
            val updated = current.map { task ->
                if (task.id == id) {
                    val newDone = !task.done
                    if (newDone) justCompleted = true
                    task.copy(
                        done = newDone,
                        completedAt = if (newDone) System.currentTimeMillis() else null
                    )
                } else task
            }
            prefs[tasksKey] = json.encodeToString(updated)
            if (justCompleted) {
                prefs[completedCountKey] = (prefs[completedCountKey] ?: 0) + 1
            }
        }
        refreshWidget()
    }

    suspend fun toggleStar(id: Long) = mutateTasks { tasks ->
        tasks.map { if (it.id == id) it.copy(starred = !it.starred) else it }
    }

    suspend fun deleteTask(id: Long) = mutateTasks { tasks ->
        tasks.filterNot { it.id == id }
    }

    suspend fun setNoteColor(color: NoteColor) {
        context.dataStore.edit { prefs -> prefs[noteColorKey] = color.name }
        refreshWidget()
    }

    private fun decodeTasks(raw: String?): List<Task> {
        val list = if (raw.isNullOrBlank()) {
            defaultTasks
        } else {
            runCatching { json.decodeFromString<List<Task>>(raw) }.getOrDefault(defaultTasks)
        }
        return pruneExpiredCompleted(list)
    }

    /** Drops tasks that have been completed for 24 hours or more. */
    private fun pruneExpiredCompleted(tasks: List<Task>): List<Task> {
        val cutoff = System.currentTimeMillis() - TWENTY_FOUR_HOURS_MILLIS
        return tasks.filterNot { it.done && (it.completedAt ?: 0L) <= cutoff }
    }

    private fun decodeColor(raw: String?): NoteColor {
        if (raw.isNullOrBlank()) return NoteColor.YELLOW
        return runCatching { NoteColor.valueOf(raw) }.getOrDefault(NoteColor.YELLOW)
    }

    private suspend fun mutateTasks(transform: (List<Task>) -> List<Task>) {
        context.dataStore.edit { prefs ->
            val current = decodeTasks(prefs[tasksKey])
            prefs[tasksKey] = json.encodeToString(transform(current))
        }
        refreshWidget()
    }

    /**
     * Refreshing widget instances is a "nice to have", not core functionality — if it fails for
     * any reason (no widget pinned yet, launcher quirk, etc.) it must never take the add/toggle/
     * delete action down with it. Swallow and move on.
     */
    private suspend fun refreshWidget() {
        runCatching { StickyNoteWidget().updateAll(context) }
    }

    companion object {
        private const val TWENTY_FOUR_HOURS_MILLIS = 24L * 60 * 60 * 1000

        val defaultTasks = listOf(
            Task(1, "Buy groceries", false),
            Task(2, "Call mom back", true, completedAt = System.currentTimeMillis()),
            Task(3, "Finish quarterly report", false),
            Task(4, "Water the plants", false)
        )
    }
}
