package com.example.stickytodo.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.glance.appwidget.updateAll
import com.example.stickytodo.widget.StickyNoteWidget
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sticky_todo_prefs")

/**
 * Single source of truth for all sticky notes (e.g. "Personal", "Work"), each with its own
 * tasks and color, plus which note is currently active. Both MainActivity (via TaskViewModel)
 * and the Glance app widget read from / write to this repository, so everything stays in sync.
 */
class TaskRepository(private val context: Context) {

    private val notesKey = stringPreferencesKey("notes_json")
    private val activeNoteIdKey = longPreferencesKey("active_note_id")
    private val completedCountKey = intPreferencesKey("completed_count")

    // Old single-note storage, kept only so existing installs can be migrated automatically.
    private val legacyTasksKey = stringPreferencesKey("tasks_json")
    private val legacyColorKey = stringPreferencesKey("note_color")

    private val json = Json { ignoreUnknownKeys = true }

    val notesFlow: Flow<List<StickyNoteData>> = context.dataStore.data.map { prefs -> decodeNotes(prefs) }

    val activeNoteIdFlow: Flow<Long> = context.dataStore.data.map { prefs ->
        resolveActiveId(prefs, decodeNotes(prefs))
    }

    val activeNoteFlow: Flow<StickyNoteData> = context.dataStore.data.map { prefs ->
        val notes = decodeNotes(prefs)
        val activeId = resolveActiveId(prefs, notes)
        notes.firstOrNull { it.id == activeId } ?: notes.first()
    }

    /** Lifetime count of tasks ever completed, across all notes — never decreases. */
    val completedCountFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[completedCountKey] ?: 0
    }

    suspend fun addNote(title: String) {
        context.dataStore.edit { prefs ->
            val notes = decodeNotes(prefs)
            val newId = (notes.maxOfOrNull { it.id } ?: 0L) + 1
            val newNote = StickyNoteData(id = newId, title = title.ifBlank { "New note" })
            prefs[notesKey] = json.encodeToString(notes + newNote)
            prefs[activeNoteIdKey] = newId
        }
        refreshWidget()
    }

    suspend fun renameNote(noteId: Long, newTitle: String) {
        if (newTitle.isBlank()) return
        context.dataStore.edit { prefs ->
            val notes = decodeNotes(prefs)
            val updated = notes.map { if (it.id == noteId) it.copy(title = newTitle.trim()) else it }
            prefs[notesKey] = json.encodeToString(updated)
        }
        refreshWidget()
    }

    suspend fun setActiveNote(noteId: Long) {
        context.dataStore.edit { prefs -> prefs[activeNoteIdKey] = noteId }
        refreshWidget()
    }

    suspend fun setNoteColor(noteId: Long, color: NoteColor) = mutateNote(noteId) { it.copy(color = color) }

    suspend fun addTask(noteId: Long, text: String) {
        if (text.isBlank()) return
        mutateNote(noteId) { note ->
            note.copy(tasks = note.tasks + Task(id = System.currentTimeMillis(), text = text.trim()))
        }
    }

    suspend fun deleteTask(noteId: Long, taskId: Long) = mutateNote(noteId) { note ->
        note.copy(tasks = note.tasks.filterNot { it.id == taskId })
    }

    suspend fun toggleStar(noteId: Long, taskId: Long) = mutateNote(noteId) { note ->
        note.copy(tasks = note.tasks.map { if (it.id == taskId) it.copy(starred = !it.starred) else it })
    }

    suspend fun toggleTask(noteId: Long, taskId: Long) {
        context.dataStore.edit { prefs ->
            val notes = decodeNotes(prefs)
            var justCompleted = false
            val updated = notes.map { note ->
                if (note.id != noteId) return@map note
                val newTasks = note.tasks.map { task ->
                    if (task.id != taskId) return@map task
                    val newDone = !task.done
                    if (newDone) justCompleted = true
                    task.copy(done = newDone, completedAt = if (newDone) System.currentTimeMillis() else null)
                }
                note.copy(tasks = newTasks)
            }
            prefs[notesKey] = json.encodeToString(updated)
            if (justCompleted) {
                prefs[completedCountKey] = (prefs[completedCountKey] ?: 0) + 1
            }
        }
        refreshWidget()
    }

    private suspend fun mutateNote(noteId: Long, transform: (StickyNoteData) -> StickyNoteData) {
        context.dataStore.edit { prefs ->
            val notes = decodeNotes(prefs)
            val updated = notes.map { if (it.id == noteId) transform(it) else it }
            prefs[notesKey] = json.encodeToString(updated)
        }
        refreshWidget()
    }

    private fun resolveActiveId(prefs: Preferences, notes: List<StickyNoteData>): Long {
        val stored = prefs[activeNoteIdKey]
        return if (stored != null && notes.any { it.id == stored }) stored else notes.first().id
    }

    /** Reads the stored notes, migrating from the old single-note format on first run, and
     *  pruning any tasks completed 24+ hours ago. */
    private fun decodeNotes(prefs: Preferences): List<StickyNoteData> {
        val raw = prefs[notesKey]
        val decoded = if (!raw.isNullOrBlank()) {
            runCatching { json.decodeFromString<List<StickyNoteData>>(raw) }.getOrNull()
        } else null

        val notes = if (!decoded.isNullOrEmpty()) {
            decoded
        } else {
            // First run after this update (or a fresh install): build one note from whatever
            // was there before, so existing tasks are never lost.
            val legacyTasks = prefs[legacyTasksKey]?.let {
                runCatching { json.decodeFromString<List<Task>>(it) }.getOrNull()
            } ?: defaultTasks
            val legacyColor = prefs[legacyColorKey]?.let {
                runCatching { NoteColor.valueOf(it) }.getOrNull()
            } ?: NoteColor.YELLOW
            listOf(StickyNoteData(id = 1L, title = "My Notes", color = legacyColor, tasks = legacyTasks))
        }

        return notes.map { note ->
            note.copy(
                tasks = pruneExpiredCompleted(note.tasks)
                    .sortedWith(compareBy<Task> { it.done }.thenByDescending { it.starred })
            )
        }
    }

    /** Drops tasks that have been completed for 24 hours or more. */
    private fun pruneExpiredCompleted(tasks: List<Task>): List<Task> {
        val cutoff = System.currentTimeMillis() - TWENTY_FOUR_HOURS_MILLIS
        return tasks.filterNot { it.done && (it.completedAt ?: 0L) <= cutoff }
    }

    /**
     * Refreshing widget instances is a "nice to have", not core functionality — if it fails for
     * any reason it must never take the underlying action down with it.
     */
    private suspend fun refreshWidget() {
        runCatching { StickyNoteWidget().updateAll(context) }
    }

    companion object {
        private const val TWENTY_FOUR_HOURS_MILLIS = 24L * 60 * 60 * 1000

        val defaultTasks = listOf(
            Task(1, "Buy groceries", false),
            Task(2, "Call mom back", true, completedAt = System.currentTimeMillis()),
            Task(3, "Finish quarterly report", false),
            Task(4, "Water the plants", false)
        )
    }
}
