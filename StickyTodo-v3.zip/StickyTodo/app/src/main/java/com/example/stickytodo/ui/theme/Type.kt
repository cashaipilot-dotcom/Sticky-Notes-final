package com.example.stickytodo.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Stand-in "handwriting" font using the built-in cursive typeface, so the project
 * compiles with zero extra setup. For a closer match to the web version's Kalam
 * font, add the Google Fonts downloadable-fonts dependency and swap HandwritingFont
 * below for a GoogleFont("Kalam") provider font family. See README.md.
 */
val HandwritingFont = FontFamily.Cursive
val UiFont = FontFamily.SansSerif

val StickyTypography = Typography(
    titleLarge = TextStyle(
        fontFamily = HandwritingFont,
        fontWeight = FontWeight.Bold,
        fontSize = 30.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = UiFont,
        fontWeight = FontWeight.Normal,
        fontSize = 17.sp
    ),
    labelSmall = TextStyle(
        fontFamily = UiFont,
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.sp
    )
)
