package com.example.stickytodo.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.ImageProvider
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.action.ActionParameters
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextDecoration
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.example.stickytodo.QuickAddTaskActivity
import com.example.stickytodo.R
import com.example.stickytodo.data.NoteColor
import com.example.stickytodo.data.Task
import com.example.stickytodo.data.TaskRepository

private val taskIdKey = ActionParameters.Key<Long>("task_id")

/** Maximum number of tasks that comfortably fit a small/medium home-screen widget. */
private const val MAX_VISIBLE_TASKS = 4

class StickyNoteWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val repository = TaskRepository(context)
        provideContent {
            val tasks by repository.tasksFlow.collectAsState(initial = TaskRepository.defaultTasks)
            val noteColor by repository.noteColorFlow.collectAsState(initial = NoteColor.YELLOW)
            StickyNoteWidgetContent(tasks = tasks, noteColor = noteColor)
        }
    }
}

private fun backgroundDrawableFor(color: NoteColor): Int = when (color) {
    NoteColor.YELLOW -> R.drawable.widget_background_yellow
    NoteColor.GREEN -> R.drawable.widget_background_green
    NoteColor.BLUE -> R.drawable.widget_background_blue
}

@Composable
private fun StickyNoteWidgetContent(tasks: List<Task>, noteColor: NoteColor) {
    val doneCount = tasks.count { it.done }

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ImageProvider(backgroundDrawableFor(noteColor)))
            .padding(12.dp)
    ) {
        Text(
            text = "To-Do",
            style = TextStyle(
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = ColorProvider(Color(0xFF44403C))
            )
        )
        Spacer(modifier = GlanceModifier.height(4.dp))

        Row(
            modifier = GlanceModifier
                .fillMaxWidth()
                .clickable(actionStartActivity<QuickAddTaskActivity>()),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "+ Add task",
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = ColorProvider(Color(0xFF8C6E54))
                )
            )
        }
        Spacer(modifier = GlanceModifier.height(6.dp))

        tasks.take(MAX_VISIBLE_TASKS).forEach { task ->
            Row(
                modifier = GlanceModifier
                    .fillMaxWidth()
                    .clickable(
                        actionRunCallback<ToggleTaskAction>(
                            actionParametersOf(taskIdKey to task.id)
                        )
                    ),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (task.done) "\u2611" else "\u2610", // ☑ / ☐
                    style = TextStyle(
                        fontSize = 14.sp,
                        color = ColorProvider(
                            if (task.done) Color(0xFF8C6E54) else Color(0xFF78716C)
                        )
                    )
                )
                Spacer(modifier = GlanceModifier.width(6.dp))
                Text(
                    text = task.text,
                    maxLines = 1,
                    style = TextStyle(
                        fontSize = 13.sp,
                        textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None,
                        color = ColorProvider(
                            if (task.done) Color(0xFF78716C) else Color(0xFF44403C)
                        )
                    )
                )
            }
        }

        if (tasks.size > MAX_VISIBLE_TASKS) {
            Text(
                text = "+${tasks.size - MAX_VISIBLE_TASKS} more",
                style = TextStyle(fontSize = 11.sp, color = ColorProvider(Color(0xFF57534E)))
            )
        }
        if (tasks.isEmpty()) {
            Text(
                text = "All clear!",
                style = TextStyle(fontSize = 13.sp, color = ColorProvider(Color(0xFF78716C)))
            )
        }

        Spacer(modifier = GlanceModifier.height(6.dp))
        Text(
            text = "$doneCount of ${tasks.size} done",
            style = TextStyle(fontSize = 10.sp, color = ColorProvider(Color(0xFF57534E)))
        )
    }
}

/** Handles taps on a task row directly from the home-screen widget. */
class ToggleTaskAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        val id = parameters[taskIdKey] ?: return
        TaskRepository(context).toggleTask(id)
    }
}
