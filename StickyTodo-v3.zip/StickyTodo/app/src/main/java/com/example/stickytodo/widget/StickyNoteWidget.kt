package com.example.stickytodo.widget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.ImageProvider
import androidx.glance.LocalContext
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.lazy.LazyColumn
import androidx.glance.appwidget.lazy.items
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextDecoration
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.example.stickytodo.MainActivity
import com.example.stickytodo.QuickAddTaskActivity
import com.example.stickytodo.R
import com.example.stickytodo.SwitchNoteActivity
import com.example.stickytodo.data.NoteColor
import com.example.stickytodo.data.StickyNoteData
import com.example.stickytodo.data.Task
import com.example.stickytodo.data.TaskRepository

private val taskIdKey = ActionParameters.Key<Long>("task_id")
private val noteIdKey = ActionParameters.Key<Long>("note_id")

class StickyNoteWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val repository = TaskRepository(context)
        provideContent {
            val note by repository.activeNoteFlow.collectAsState(initial = null)
            StickyNoteWidgetContent(note = note)
        }
    }
}

private fun backgroundDrawableFor(color: NoteColor): Int = when (color) {
    NoteColor.YELLOW -> R.drawable.widget_background_yellow
    NoteColor.GREEN -> R.drawable.widget_background_green
    NoteColor.BLUE -> R.drawable.widget_background_blue
}

@Composable
private fun StickyNoteWidgetContent(note: StickyNoteData?) {
    val context = LocalContext.current

    if (note == null) {
        Column(
            modifier = GlanceModifier
                .fillMaxSize()
                .background(ImageProvider(R.drawable.widget_background_yellow))
                .padding(12.dp)
        ) {
            Text(text = "Loading…", style = TextStyle(fontSize = 13.sp, color = ColorProvider(Color(0xFF44403C))))
        }
        return
    }

    val tasks = note.tasks
    val doneCount = tasks.count { it.done }

    val addTaskIntent = Intent(context, QuickAddTaskActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    val openAppIntent = Intent(context, MainActivity::class.java).apply {
        action = Intent.ACTION_MAIN
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val switchNoteIntent = Intent(context, SwitchNoteActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ImageProvider(backgroundDrawableFor(note.color)))
            .padding(12.dp)
    ) {
        Row(
            modifier = GlanceModifier
                .fillMaxWidth()
                .clickable(actionStartActivity(switchNoteIntent)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "📝 ${note.title} ▾",
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = ColorProvider(Color(0xFF44403C))
                )
            )
        }
        Spacer(modifier = GlanceModifier.height(4.dp))

        Row(
            modifier = GlanceModifier
                .fillMaxWidth()
                .clickable(actionStartActivity(addTaskIntent)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "+ Add task",
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = ColorProvider(Color(0xFF8C6E54))
                )
            )
        }
        Spacer(modifier = GlanceModifier.height(6.dp))

        if (tasks.isEmpty()) {
            Text(
                text = "All clear!",
                style = TextStyle(fontSize = 13.sp, color = ColorProvider(Color(0xFF78716C)))
            )
        } else {
            LazyColumn(
                modifier = GlanceModifier.fillMaxWidth().height(120.dp)
            ) {
                items(tasks, itemId = { it.id }) { task ->
                    Row(
                        modifier = GlanceModifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clickable(
                                actionRunCallback<ToggleTaskAction>(
                                    actionParametersOf(noteIdKey to note.id, taskIdKey to task.id)
                                )
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (task.done) "\u2611" else "\u2610", // ☑ / ☐
                            style = TextStyle(
                                fontSize = 14.sp,
                                color = ColorProvider(
                                    if (task.done) Color(0xFF8C6E54) else Color(0xFF78716C)
                                )
                            )
                        )
                        Spacer(modifier = GlanceModifier.width(6.dp))
                        Text(
                            text = task.text,
                            maxLines = 1,
                            style = TextStyle(
                                fontSize = 13.sp,
                                textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None,
                                color = ColorProvider(
                                    if (task.done) Color(0xFF78716C) else Color(0xFF44403C)
                                )
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = GlanceModifier.height(6.dp))
        Text(
            text = "$doneCount of ${tasks.size} done",
            style = TextStyle(fontSize = 10.sp, color = ColorProvider(Color(0xFF57534E)))
        )

        Spacer(modifier = GlanceModifier.height(4.dp))
        Row(
            modifier = GlanceModifier
                .fillMaxWidth()
                .clickable(actionStartActivity(openAppIntent)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "📱 Open app",
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = ColorProvider(Color(0xFF8C6E54))
                )
            )
        }
    }
}

/** Handles taps on a task row directly from the home-screen widget. */
class ToggleTaskAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        val noteId = parameters[noteIdKey] ?: return
        val taskId = parameters[taskIdKey] ?: return
        TaskRepository(context).toggleTask(noteId, taskId)
    }
}
