package com.example.stickytodo.ui.theme

import androidx.compose.ui.graphics.Color

// Sticky note paper tones — warm cream / muted sage / dusty blush,
// matching the soft scrapbook aesthetic.
val NoteYellowLight = Color(0xFFFDF6EC) // "Cream"
val NoteYellowMid = Color(0xFFF3E6CE)
val NoteYellowDark = Color(0xFFE8D3A8)

val NoteGreenLight = Color(0xFFF1F5EC) // "Sage"
val NoteGreenMid = Color(0xFFDDE7CD)
val NoteGreenDark = Color(0xFFB9CDA0)

val NoteBlueLight = Color(0xFFFBEEEC) // "Blush"
val NoteBlueMid = Color(0xFFF3D9D6)
val NoteBlueDark = Color(0xFFE3B8B4)

// Ink / text
val InkDark = Color(0xFF44403C)
val InkMuted = Color(0xFF78716C)

// Page background (soft beige "flat lay" surface) + accents
val CorkBrown = Color(0xFFF0E6D8)
val CorkBrownDark = Color(0xFF7C5A32)
val PinRed = Color(0xFFB91C1C)
val PinRedHighlight = Color(0xFFF87171)
val CheckGreen = Color(0xFF8C6E54)
