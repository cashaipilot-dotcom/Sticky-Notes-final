package com.example.stickytodo.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val StickyColorScheme = lightColorScheme(
    primary = InkDark,
    secondary = CheckGreen,
    background = CorkBrown,
    surface = NoteYellowMid,
    onPrimary = NoteYellowLight,
    onBackground = InkDark,
    onSurface = InkDark
)

@Composable
fun StickyTodoTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StickyColorScheme,
        typography = StickyTypography,
        content = content
    )
}
