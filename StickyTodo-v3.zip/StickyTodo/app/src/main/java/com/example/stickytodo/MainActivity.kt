package com.example.stickytodo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.example.stickytodo.ui.StickyNoteScreen
import com.example.stickytodo.ui.theme.StickyTodoTheme
import com.example.stickytodo.viewmodel.TaskViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: TaskViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StickyTodoTheme {
                StickyNoteScreen(viewModel = viewModel)
            }
        }
    }
}
