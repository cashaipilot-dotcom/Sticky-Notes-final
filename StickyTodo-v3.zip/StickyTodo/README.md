# Sticky To-Do (Kotlin + Jetpack Compose + Glance)

A native Android port of the sticky-note to-do web app.

## How the pieces map from the React version

| React version | Android version |
|---|---|
| Sticky note UI, add/check/delete | `MainActivity` + `StickyNoteScreen.kt` (Jetpack Compose) |
| "Mini Widget Preview" toggle simulating a home screen | A **real** Glance `AppWidget` (`widget/StickyNoteWidget.kt`) you can actually place on your home screen — tapping a task's checkbox there ticks it off for real |
| React `useState` | `TaskViewModel` (`StateFlow`) |
| `localStorage` (not available in the web preview) | `DataStore<Preferences>` in `TaskRepository.kt` — real, working persistence shared by the app and the widget |

Tapping **"Add widget to Home Screen"** in the app calls `AppWidgetManager.requestPinAppWidget(...)`, which asks Android to place the widget directly (Android 8.0+). You can also long-press your home screen → Widgets → Sticky To-Do the normal way.

## Opening the project

1. Unzip this folder.
2. Android Studio → **Open** → select the `StickyTodo` folder.
3. Let Gradle sync (it will download dependencies the first time — needs internet access).
4. Run the `app` configuration on a device/emulator running **API 26+**.

## Notes / things worth double-checking after import

I wrote and organized this project by hand in a sandbox without Android Studio or the Android SDK, so it hasn't been compiled or run — treat it as a solid, complete first draft rather than a verified build. The most likely spots to need a small tweak, in rough order of likelihood:

- **Dependency versions** (`compose-bom`, `glance-appwidget`, AGP, Kotlin) — pinned to versions current as of early 2026 training data. Android Studio will flag if any need bumping.
- **Handwriting font** — uses `FontFamily.Cursive` (built-in) so it compiles with zero setup. To match the web version's "Kalam" look exactly, add:
  ```kotlin
  implementation("androidx.compose.ui:ui-text-google-fonts:1.6.8")
  ```
  and swap `HandwritingFont` in `ui/theme/Type.kt` for a downloadable `GoogleFont("Kalam")` provider font.
- **Glance widget text styling API** (`androidx.glance.text.TextStyle/FontWeight/TextDecoration`) is a separate, smaller API surface from Compose UI's — I used it directly rather than reusing the app's Compose text styles, which is correct but worth a glance (no pun intended) if Android Studio flags anything.
- **`minSdk = 26`** — chosen for Glance/DataStore comfortably; can be lowered if you need to support older devices (Glance widgets generally target 23+).

## Project structure

```
app/src/main/java/com/example/stickytodo/
├── MainActivity.kt
├── data/
│   ├── Task.kt
│   └── TaskRepository.kt        # DataStore-backed, shared by app + widget
├── viewmodel/
│   └── TaskViewModel.kt
├── ui/
│   ├── StickyNoteScreen.kt       # the sticky note screen
│   └── theme/                    # colors, type, Material3 theme
└── widget/
    ├── StickyNoteWidget.kt       # Glance AppWidget (the real home-screen widget)
    └── StickyNoteWidgetReceiver.kt
```
