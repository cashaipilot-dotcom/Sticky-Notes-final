package com.example.stickytodo.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.stickytodo.widget.StickyNoteWidget
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sticky_todo_prefs")

/**
 * Single source of truth for tasks. Both MainActivity (via TaskViewModel) and the
 * Glance app widget read from / write to this repository, so the two stay in sync:
 * ticking a box on the home-screen widget updates the in-app list instantly and
 * vice versa.
 */
class TaskRepository(private val context: Context) {

    private val tasksKey = stringPreferencesKey("tasks_json")
    private val json = Json { ignoreUnknownKeys = true }

    val tasksFlow: Flow<List<Task>> = context.dataStore.data.map { prefs ->
        decode(prefs[tasksKey])
    }

    suspend fun addTask(text: String) = mutate { tasks ->
        tasks + Task(id = System.currentTimeMillis(), text = text, done = false)
    }

    suspend fun toggleTask(id: Long) = mutate { tasks ->
        tasks.map { if (it.id == id) it.copy(done = !it.done) else it }
    }

    suspend fun deleteTask(id: Long) = mutate { tasks ->
        tasks.filterNot { it.id == id }
    }

    private fun decode(raw: String?): List<Task> {
        if (raw.isNullOrBlank()) return defaultTasks
        return runCatching { json.decodeFromString<List<Task>>(raw) }.getOrDefault(defaultTasks)
    }

    private suspend fun mutate(transform: (List<Task>) -> List<Task>) {
        context.dataStore.edit { prefs ->
            val current = decode(prefs[tasksKey])
            prefs[tasksKey] = json.encodeToString(transform(current))
        }
        // Refresh any home-screen widget instances so they reflect the change immediately.
        StickyNoteWidget().updateAll(context)
    }

    companion object {
        val defaultTasks = listOf(
            Task(1, "Buy groceries", false),
            Task(2, "Call mom back", true),
            Task(3, "Finish quarterly report", false),
            Task(4, "Water the plants", false)
        )
    }
}
