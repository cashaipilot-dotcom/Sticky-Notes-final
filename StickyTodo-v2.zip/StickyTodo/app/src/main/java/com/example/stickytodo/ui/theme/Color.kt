package com.example.stickytodo.ui.theme

import androidx.compose.ui.graphics.Color

// Sticky note
val NoteYellowLight = Color(0xFFFEF9C3)
val NoteYellowMid = Color(0xFFFDE047)
val NoteYellowDark = Color(0xFFFACC15)

// Ink / text
val InkDark = Color(0xFF44403C)
val InkMuted = Color(0xFF78716C)

// Board + accents
val CorkBrown = Color(0xFFA97B46)
val CorkBrownDark = Color(0xFF7C5A32)
val PinRed = Color(0xFFB91C1C)
val PinRedHighlight = Color(0xFFF87171)
val CheckGreen = Color(0xFF16A34A)
