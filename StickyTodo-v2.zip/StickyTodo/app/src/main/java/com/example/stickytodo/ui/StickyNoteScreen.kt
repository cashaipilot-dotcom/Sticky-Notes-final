package com.example.stickytodo.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.stickytodo.data.Task
import com.example.stickytodo.ui.theme.*
import com.example.stickytodo.viewmodel.TaskViewModel
import com.example.stickytodo.widget.StickyNoteWidgetReceiver

@Composable
fun StickyNoteScreen(viewModel: TaskViewModel) {
    val tasks by viewModel.tasks.collectAsState()
    var input by remember { mutableStateOf("") }
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CorkBrown)
    ) {
        CorkTexture(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            StickyNoteCard(
                tasks = tasks,
                input = input,
                onInputChange = { input = it },
                onAdd = {
                    viewModel.addTask(input)
                    input = ""
                },
                onToggle = viewModel::toggleTask,
                onDelete = viewModel::deleteTask
            )

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedButton(
                onClick = {
                    val appWidgetManager = AppWidgetManager.getInstance(context)
                    val provider = ComponentName(context, StickyNoteWidgetReceiver::class.java)
                    if (appWidgetManager.isRequestPinAppWidgetSupported) {
                        appWidgetManager.requestPinAppWidget(provider, null, null)
                    }
                },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = NoteYellowLight)
            ) {
                Icon(Icons.Filled.PushPin, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add widget to Home Screen")
            }
        }
    }
}

@Composable
private fun StickyNoteCard(
    tasks: List<Task>,
    input: String,
    onInputChange: (String) -> Unit,
    onAdd: () -> Unit,
    onToggle: (Long) -> Unit,
    onDelete: (Long) -> Unit
) {
    val doneCount = tasks.count { it.done }

    Box(
        modifier = Modifier
            .widthIn(max = 360.dp)
            .graphicsLayer { rotationZ = -1.5f }
    ) {
        Column(
            modifier = Modifier
                .shadow(elevation = 18.dp, shape = RoundedCornerShape(4.dp), clip = false)
                .clip(RoundedCornerShape(4.dp))
                .background(
                    Brush.linearGradient(listOf(NoteYellowLight, NoteYellowMid, NoteYellowDark))
                )
                .padding(start = 22.dp, end = 22.dp, top = 34.dp, bottom = 18.dp)
        ) {
            Text(
                text = "To-Do List",
                style = MaterialTheme.typography.titleLarge,
                color = InkDark
            )

            Spacer(modifier = Modifier.height(14.dp))

            AddTaskRow(input = input, onInputChange = onInputChange, onAdd = onAdd)

            Spacer(modifier = Modifier.height(10.dp))

            if (tasks.isEmpty()) {
                Text(
                    text = "Nothing here yet — add something above!",
                    style = MaterialTheme.typography.bodyLarge,
                    color = InkMuted
                )
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 320.dp)
                ) {
                    items(tasks, key = { it.id }) { task ->
                        TaskRow(task = task, onToggle = onToggle, onDelete = onDelete)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            HorizontalDivider(color = InkMuted.copy(alpha = 0.25f))
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "$doneCount of ${tasks.size} done",
                style = MaterialTheme.typography.labelSmall,
                color = InkMuted
            )
        }

        // Pushpin, overlapping the top edge of the note.
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-16).dp)
                .shadow(elevation = 6.dp, shape = CircleShape)
                .size(32.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(PinRedHighlight, PinRed))),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.PushPin,
                contentDescription = null,
                tint = Color(0xFFFECACA),
                modifier = Modifier.size(16.dp).graphicsLayer { rotationZ = 45f }
            )
        }

        // Curled bottom-right corner.
        CornerCurl(modifier = Modifier.align(Alignment.BottomEnd))
    }
}

@Composable
private fun AddTaskRow(input: String, onInputChange: (String) -> Unit, onAdd: () -> Unit) {
    Row(verticalAlignment = Alignment.Bottom) {
        TextField(
            value = input,
            onValueChange = onInputChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Add a task...", color = InkMuted.copy(alpha = 0.7f)) },
            textStyle = MaterialTheme.typography.bodyLarge.copy(color = InkDark),
            singleLine = true,
            colors = TextFieldDefaults.colors(
                unfocusedContainerColor = Color.Transparent,
                focusedContainerColor = Color.Transparent,
                unfocusedIndicatorColor = InkMuted.copy(alpha = 0.4f),
                focusedIndicatorColor = InkDark,
                cursorColor = InkDark
            )
        )
        Spacer(modifier = Modifier.width(8.dp))
        Button(
            onClick = onAdd,
            colors = ButtonDefaults.buttonColors(containerColor = InkDark, contentColor = NoteYellowLight),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Add", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun TaskRow(task: Task, onToggle: (Long) -> Unit, onDelete: (Long) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle(task.id) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CheckCircle(done = task.done)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "• ${task.text}",
            style = MaterialTheme.typography.bodyLarge,
            color = if (task.done) InkMuted else InkDark,
            textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = { onDelete(task.id) }, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Filled.Delete, contentDescription = "Delete task", tint = InkMuted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun CheckCircle(done: Boolean) {
    Box(
        modifier = Modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(if (done) CheckGreen else Color.Transparent),
        contentAlignment = Alignment.Center
    ) {
        if (done) {
            Icon(Icons.Filled.Check, contentDescription = null, tint = NoteYellowLight, modifier = Modifier.size(14.dp))
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(Color.Transparent)
            )
        }
    }
}

@Composable
private fun CornerCurl(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(28.dp)) {
        val w = size.width
        val h = size.height

        // Shadow cast onto the note by the lifted corner.
        val shadowPath = Path().apply {
            moveTo(w, 0f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(shadowPath, color = Color.Black.copy(alpha = 0.18f))

        // The lifted paper triangle itself, slightly lighter than the note.
        val curlPath = Path().apply {
            moveTo(w, 0f)
            lineTo(w, h * 0.78f)
            lineTo(w * 0.22f, h)
            lineTo(w, h)
            close()
        }
        drawPath(
            curlPath,
            brush = Brush.linearGradient(
                colors = listOf(NoteYellowLight, NoteYellowDark),
                start = Offset(w * 0.3f, h * 0.3f),
                end = Offset(w, h)
            )
        )
    }
}

@Composable
private fun CorkTexture(modifier: Modifier = Modifier) {
    // Lightweight fleck pattern to suggest a corkboard without needing a bitmap asset.
    Canvas(modifier = modifier) {
        val step = 26f
        var y = 0f
        var row = 0
        while (y < size.height) {
            var x = if (row % 2 == 0) 0f else step / 2f
            while (x < size.width) {
                drawCircle(
                    color = Color.Black.copy(alpha = 0.10f),
                    radius = 1.6f,
                    center = Offset(x, y)
                )
                x += step
            }
            y += step
            row++
        }
    }
}
