package com.example.stickytodo.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.stickytodo.data.Task
import com.example.stickytodo.data.TaskRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TaskViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = TaskRepository(application)

    val tasks: StateFlow<List<Task>> = repository.tasksFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = TaskRepository.defaultTasks
    )

    fun addTask(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch { repository.addTask(text.trim()) }
    }

    fun toggleTask(id: Long) {
        viewModelScope.launch { repository.toggleTask(id) }
    }

    fun deleteTask(id: Long) {
        viewModelScope.launch { repository.deleteTask(id) }
    }
}
